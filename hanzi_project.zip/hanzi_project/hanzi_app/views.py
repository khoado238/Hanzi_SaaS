# hanzi_app/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required(login_url='/admin/login/') 
def hanzi_tool_view(request):
    # Mặc định lấy tên đăng nhập
    watermark_text = request.user.username 
    
    # Kiểm tra xem có cấu hình Watermark trong Admin chưa
    if hasattr(request.user, 'partnerprofile'):
        if request.user.partnerprofile.watermark_text:
            watermark_text = request.user.partnerprofile.watermark_text
    
    context = {
        'watermark_text': watermark_text
    }
    
    return render(request, 'hanzi_generator.html', context)